import random
import re


SYNONYMS = {

    "cleaned": [
        "cleared",
        "sanitized",
        "maintained"
    ],

    "replaced": [
        "changed",
        "substituted",
        "renewed"
    ],

    "blocked": [
        "restricted",
        "obstructed"
    ],

    "overheating": [
        "excessive heating",
        "high temperature issue"
    ],

    "inspection": [
        "checking",
        "verification",
        "monitoring"
    ]
}


def paraphrase_text(text):

    words = re.findall(
        r'\w+|\S',
        text
    )

    new_words = []

    for word in words:

        clean_word = word.lower()

        if clean_word in SYNONYMS:

            replacement = random.choice(
                SYNONYMS[clean_word]
            )

            # preserve capitalization
            if word[0].isupper():

                replacement = replacement.capitalize()

            new_words.append(
                replacement
            )

        else:

            new_words.append(word)

    return " ".join(new_words)


